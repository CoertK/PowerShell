﻿$driver = "Canon Generic Plus PCL6"
$address = "10.1.100.133"
$name = "Ploum Wachtrij"
$sleep = "3"

#Invoke-Command {pnputil.exe -a C:\driver\CNP60MA64.INF }

start-sleep $sleep

Remove-Printer -Name $name

Start-Sleep $sleep

Remove-PrinterPort -Name $address

Start-Sleep $sleep

Remove-PrinterDriver -Name $driver