﻿$driver = "Canon Generic Plus PCL6"
$address = "10.1.100.133"
$name = "Ploum Wachtrij"
$sleep = "3"

#Invoke-Command {pnputil.exe -a C:\driver\CNP60MA64.INF }


Add-PrinterDriver -Name $driver

Start-Sleep $sleep

Add-PrinterPort -Name $address -PrinterHostAddress $address

start-sleep $sleep

Add-Printer -DriverName $driver -Name $name -PortName $address